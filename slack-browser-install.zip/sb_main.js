'use strict';

const path = require('path');
const fs = require('fs');
const e = require('electron');
const { app, BrowserWindow, ipcMain, globalShortcut, session, screen, shell, clipboard } = e;

const MOD_DIR = __dirname;
const TOOLBAR_H = 72;
const SLACK_TOP_H = 52;   // Slack's top nav/search bar height; keep browser below it
let toolbarH = TOOLBAR_H;
const LEFT_RATIO = 0.25;   // Slack keeps 25% on the left, browser overlays the rest
const ACCEL = 'Control+Alt+B';
const DEFAULT_HOME = 'https://duckduckgo.com/';
const DEFAULT_PHRASE = 'enjoy you';
const LOG = path.join(MOD_DIR, 'sb.log');

try {
  fs.appendFileSync(LOG, '[import] start electron=' + process.versions.electron + ' pid=' + process.pid + '\n');
} catch (_iErr) {}

const LOG_MAX = 2 * 1024 * 1024;  // sb.log is append-only while Slack runs; keep it bounded
function log(...args) {
  try {
    try {
      if (fs.statSync(LOG).size > LOG_MAX) {
        try { fs.unlinkSync(LOG + '.1'); } catch (_old) {}
        fs.renameSync(LOG, LOG + '.1');
      }
    } catch (_rot) {}
    fs.appendFileSync(LOG, '[' + new Date().toISOString() + '] ' + args.join(' ') + '\n');
  } catch (_) {}
}

try {
  process.on('uncaughtException', (err) => { log('UNCAUGHT', err && (err.stack || err)); });
  process.on('unhandledRejection', (err) => { log('REJECTION', err && (err.stack || String(err))); });
} catch (_) {}

// ---- userData: if the launcher provided --user-data-dir, respect it; otherwise use the
// real Slack profile dir.
try {
  const usesFlag = process.argv.some((a) => String(a).startsWith('--user-data-dir'));
  if (!usesFlag) {
    const defaultData = path.join(app.getPath('appData'), 'Slack');
    const fixUserData = () => {
      try { app.setPath('userData', defaultData); } catch (_) {}
    };
    process.nextTick(fixUserData);
    app.on('ready', () => { setTimeout(fixUserData, 0); });
  }
} catch (_) {}

// ---- state
const S = {
  shown: false,
  toolbar: null,
  tabs: [],
  activeTabId: null,
  parent: null,
  url: '',
  ipcBound: false,
  opacity: 100,   // browser transparency, 20..100, persisted in sb_ui.json
  autolockMin: 30, // auto-lock seconds after leaving own DM / minimize, 0 = off; sb_ui.json
  paletteOpen: false,
};
let tabCounter = 0;
let settingsWin = null;
function openSettingsWindow() {
  try {
    if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.focus(); return; }
    const wb = (S.parent && !S.parent.isDestroyed()) ? S.parent.getBounds() : { x: 100, y: 100, width: 900, height: 700 };
    const w = new BrowserWindow({
      width: 280, height: 470,
      x: Math.max(0, wb.x + wb.width - 290),
      y: Math.max(0, wb.y + 60),
      frame: false, resizable: false, skipTaskbar: true, alwaysOnTop: true,
      webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false,
        preload: path.join(MOD_DIR, 'sb_toolbar_preload.cjs') },
    });
    settingsWin = w;
    w.loadFile(path.join(MOD_DIR, 'sb_settings.html')).catch((err) => { log('settings load err', String(err && err.message)); });
    // defer blur-close to avoid a close-during-creation race
    setTimeout(() => {
      try {
        if (!w || w.isDestroyed()) return;
        w.on('blur', () => { try { if (w && !w.isDestroyed()) w.close(); } catch (_) {} });
      } catch (_) {}
    }, 400);
    w.on('closed', () => { settingsWin = null; });
    log('settings window opened');
  } catch (err) {
    settingsWin = null;
    log('settings window err', String(err && (err.stack || err.message)));
  }
}

// ---- user data store (bookmarks + UI prefs); optional, so a missing file can
// never stop Slack from booting
let store = null;
function getStore() {
  if (store) return store;
  try { store = require(path.join(MOD_DIR, 'sb_store.cjs')); return store; }
  catch (err) { log('store module missing, using inline fallback: ' + String(err && err.message)); }
  // inline fallback so UI prefs / bookmarks still persist when sb_store.cjs is absent
  const fs = require('fs'); const p = require('path');
  function readJSON(f, fb) { try { return JSON.parse(fs.readFileSync(p.join(MOD_DIR, f), 'utf8')); } catch (_) { return fb; } }
  function writeJSON(f, v) { try { fs.writeFileSync(p.join(MOD_DIR, f), JSON.stringify(v), 'utf8'); return true; } catch (_) { return false; } }
  function norm(u) { return String(u || '').toLowerCase().replace(/\/+$/, ''); }
  const MAXB = 60;
  const shim = {
    listBookmarks() {
      const v = readJSON('sb_bookmarks.json', []);
      return Array.isArray(v) ? v.filter((b) => b && typeof b.url === 'string' && b.url) : [];
    },
    addBookmark(url, title) {
      url = String(url || '').trim();
      if (!url) return { list: this.listBookmarks(), added: false };
      const all = this.listBookmarks();
      const key = norm(url);
      const idx = all.findIndex((b) => norm(b.url) === key);
      const clean = String(title || '').trim().slice(0, 80) || url;
      if (idx >= 0) { all[idx].title = clean; writeJSON('sb_bookmarks.json', all); return { list: all, added: false, existed: true }; }
      all.unshift({ url: url, title: clean, added: new Date().toISOString() });
      while (all.length > MAXB) all.pop();
      writeJSON('sb_bookmarks.json', all);
      return { list: all, added: true };
    },
    removeBookmark(url) {
      const key = norm(url);
      const all = this.listBookmarks();
      const next = all.filter((b) => norm(b.url) !== key);
      writeJSON('sb_bookmarks.json', next);
      return next;
    },
    getUI() {
      const v = readJSON('sb_ui.json', {});
      return (v && typeof v === 'object' && !Array.isArray(v)) ? v : {};
    },
    setUI(patch) {
      const v = Object.assign(this.getUI(), (patch && typeof patch === 'object') ? patch : {});
      writeJSON('sb_ui.json', v);
      return v;
    },
  };
  store = shim;
  return store;
}

function activeProfileId() {
  const st = getStore();
  try { return (st && st.getActiveProfileId) ? st.getActiveProfileId() : 'personal'; } catch (_) { return 'personal'; }
}

function activeHome() {
  const st = getStore();
  try {
    const p = st && st.getProfile ? st.getProfile(activeProfileId()) : null;
    return (p && p.home) || DEFAULT_HOME;
  } catch (_) { return DEFAULT_HOME; }
}

function activePartition() {
  const st = getStore();
  try { return (st && st.partitionFor) ? st.partitionFor(activeProfileId()) : 'persist:slack-embedded-browser-personal'; } catch (_) {
    return 'persist:slack-embedded-browser-personal';
  }
}

function activeProfile() {
  const st = getStore();
  try { return st && st.getProfile ? st.getProfile(activeProfileId()) : { id: 'personal', name: 'Personal', color: '#3ddc97', home: DEFAULT_HOME }; } catch (_) {
    return { id: 'personal', name: 'Personal', color: '#3ddc97', home: DEFAULT_HOME };
  }
}

let blockerMod = null;
function getBlocker() {
  if (blockerMod) return blockerMod;
  try {
    blockerMod = require(path.join(MOD_DIR, 'sb_blocker.cjs'));
    blockerMod.loadList(path.join(MOD_DIR, 'sb_easylist.txt'));
    const st = getStore();
    const on = st && st.getUI ? st.getUI().blocker : undefined;
    blockerMod.setEnabled(on !== false);
  } catch (err) { log('blocker unavailable', String(err && err.message)); }
  return blockerMod;
}

let searchMod = null;
function getSearch() {
  if (searchMod) return searchMod;
  try { searchMod = require(path.join(MOD_DIR, 'sb_search.cjs')); } catch (_) {}
  return searchMod;
}

// ---- transparency. WebContentsView has no setOpacity (electron/electron#45104),
// so the fallback is CSS opacity on each document, re-applied after navigation.
// ---- transparency. We keep the page TEXT at full opacity and only make the
// page's own background transparent, so the Slack DM behind the browser shows
// through (a glass effect) while the browser content stays readable.
function makeViewTransparent(view) {
  try { if (view && typeof view.setBackgroundColor === 'function') view.setBackgroundColor('#00000000'); } catch (_) {}
  try { if (view && view.webContents && typeof view.webContents.setBackgroundColor === 'function') view.webContents.setBackgroundColor('#00000000'); } catch (_) {}
}
function applyViewOpacity(view, op) {
  if (!view) return;
  try {
    if (typeof view.setOpacity === 'function') { view.setOpacity(op); return; }  // BrowserView path
  } catch (_) {}
  try {
    const cw = view.webContents;
    if (cw && !cw.isDestroyed()) {
      const js = '(function(){try{var d=document,e=d.getElementById("sb-trans");var need=' + (op < 0.999) + ';'
        + 'if(need && !e){e=d.createElement("style");e.id="sb-trans";e.textContent="html,body{background:transparent!important;background-color:transparent!important}";d.documentElement.appendChild(e);}'
        + 'else if(!need && e){e.remove();}'
        + 'd.documentElement.style.opacity=need?String(' + op + '):"";}catch(_){}})()';
      cw.executeJavaScript(js, true).catch(() => {});
    }
  } catch (_) {}
}

function transparencyOp() {
  const v = Number(S.opacity);
  return Math.max(0.2, Math.min(1, isFinite(v) ? v / 100 : 1));
}

function applyTransparency() {
  const op = transparencyOp();
  applyViewOpacity(S.toolbar, op);
  for (const t of S.tabs) applyViewOpacity(t.view, op);
}

const hasWCV = () => typeof e.WebContentsView === 'function';

function createView(prefs) {
  let v;
  if (hasWCV()) v = new e.WebContentsView({ webPreferences: prefs, backgroundColor: '#00000000' });
  else v = new e.BrowserView({ webPreferences: prefs, backgroundColor: '#00000000' });
  makeViewTransparent(v);
  return v;
}

function attachView(win, view) {
  if (!win || !view) return;
  if (win.isDestroyed()) return;
  if (hasWCV()) {
    if (!win.contentView.children.includes(view)) win.contentView.addChildView(view);
  } else {
    try { win.removeBrowserView(view); } catch (_) {}
    win.addBrowserView(view);
  }
}

function detachView(win, view) {
  if (!win || !view || win.isDestroyed()) return;
  try {
    if (hasWCV()) win.contentView.removeChildView(view);
    else win.removeBrowserView(view);
  } catch (_) {}
}

function setBounds(view, rect) {
  try { view.setBounds(rect); } catch (_) {}
}

// ---- header stripping for our partition only
function setupSession(part) {
  if (!part) return;
  // createTab() calls this for every tab; without the guard each tab stacked another
  // onHeadersReceived handler on the same session.
  if (part.__sbConfigured) return;
  part.__sbConfigured = true;
  part.webRequest.onHeadersReceived({ urls: ['*://*/*'] }, (details, cb) => {
    const h = details.responseHeaders;
    if (h) {
      for (const k of Object.keys(h)) {
        if (/^x-frame-options$/i.test(k)) delete h[k];
        else if (/^content-security-policy$/i.test(k)) delete h[k];
        else if (/^content-security-policy-report-only$/i.test(k)) delete h[k];
        else if (/^cross-origin-opener-policy$/i.test(k)) delete h[k];
        else if (/^cross-origin-embedder-policy$/i.test(k)) delete h[k];
      }
    }
    cb({ responseHeaders: h });
  });
  // make UA look like plain Chrome (some sites reject Slack/Electron UAs)
  try {
    const ua = part.getUserAgent() || '';
    part.setUserAgent(
      ua.replace(/\s*Slack_SSB\/[\d.]+/gi, '')
        .replace(/\s*Slack\/[\d.]+/gi, '')
        .replace(/\s*Electron\/[\d.]+/gi, '')
    );
  } catch (_) {}
  try {
    const blk = getBlocker();
    if (blk) {
      part.webRequest.onBeforeRequest({ urls: ['*://*/*'] }, (details, cb) => {
        try {
          if (blk.shouldBlock(details.url)) return cb({ cancel: true });
        } catch (_) {}
        cb({});
      });
    }
  } catch (err) { log('blocker bind err', String(err && err.message)); }
  try {
    part.on('will-download', (_e, item) => {
      try {
        const rec = {
          id: 'dl' + Date.now() + Math.floor(Math.random() * 999),
          url: item.getURL(),
          filename: item.getFilename(),
          state: 'progressing',
          bytes: 0,
          total: item.getTotalBytes() || 0,
        };
        const st = getStore();
        if (st && st.addDownload) st.addDownload(rec, activeProfileId());
        item.on('updated', (_ev, state) => {
          try {
            if (st && st.updateDownload) st.updateDownload(rec.id, { state: state, bytes: item.getReceivedBytes(), total: item.getTotalBytes() }, activeProfileId());
          } catch (_) {}
        });
        item.once('done', (_ev, state) => {
          try {
            if (st && st.updateDownload) st.updateDownload(rec.id, { state: state, bytes: item.getReceivedBytes(), path: item.getSavePath() }, activeProfileId());
            sendStatus(state === 'completed' ? ('downloaded ' + rec.filename) : ('download ' + state), state === 'completed' ? 'ok' : 'err');
          } catch (_) {}
        });
      } catch (err) { log('download err', String(err && err.message)); }
    });
  } catch (err) { log('download bind err', String(err && err.message)); }
}

// ---- toolbar/status channel
function pushUpdate() {
  const tw = S.toolbar && S.toolbar.webContents;
  if (!tw || tw.isDestroyed()) return;
  const active = getActiveTab();
  let u = '';
  let loading = false;
  try {
    const cw = active && active.view && active.view.webContents;
    if (cw) { u = cw.getURL(); loading = cw.isLoading(); }
  } catch (_) {}
  const tabs = S.tabs.map((t) => ({ id: t.id, title: t.title || t.url, url: t.url, active: t.id === S.activeTabId }));
  const p = activeProfile();
  tw.send('sb-update', {
    url: u, loading, tabs, activeTabId: S.activeTabId,
    profile: { id: p.id, name: p.name, color: p.color, home: p.home },
    profiles: (function () { try { return getStore().listProfiles(); } catch (_) { return []; } })(),
    blocker: (function () { const b = getBlocker(); return b ? b.isEnabled() : false; })(),
  });
}

function normalize(u) {
  u = String(u || '').trim();
  if (!u) return activeHome();
  if (/^(https?|file):/i.test(u)) return u;
  if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/|$)/.test(u)) return 'https://' + u;
  // treat as search
  return 'https://duckduckgo.com/?q=' + encodeURIComponent(u);
}

function getActiveTab() {
  return S.tabs.find((t) => t.id === S.activeTabId) || S.tabs[0] || null;
}

function activeWC() {
  const t = getActiveTab();
  return (t && t.view && t.view.webContents) || null;
}

function recordHistory(url, title) {
  try {
    const st = getStore();
    if (st && st.addHistory) st.addHistory(url, title, activeProfileId());
  } catch (_) {}
}

function createTab(url, switchTo) {
  if (switchTo === undefined) switchTo = true;
  const part = session.fromPartition(activePartition());
  setupSession(part);
  const view = createView({
    nodeIntegration: false,
    contextIsolation: true,
    sandbox: true,
    preload: path.join(MOD_DIR, 'sb_content_preload.cjs'),
    session: part,
  });
  const tab = { id: 't' + (++tabCounter), view, url: normalize(url || activeHome()), title: '' };
  const cw = view.webContents;
  // mouse-wheel + keyboard zoom (independent of page JS)
  cw.on('input-event', (_ev, ie) => {
    try {
      const _mods = Array.isArray(ie.modifiers) ? ie.modifiers : [];
      const _ctrl = !!(ie.control || ie.controlKey || _mods.indexOf('control') >= 0 || _mods.indexOf('ctrl') >= 0);
      const _meta = !!(ie.meta || ie.metaKey || _mods.indexOf('meta') >= 0 || _mods.indexOf('command') >= 0);
      if (ie.type === 'mouseWheel' && (_ctrl || _meta)) {
        // Wheel zoom is owned by sb_content_preload.cjs (it turns the wheel into
        // sb-zoom). Calling preventDefault() here would swallow the event before the
        // renderer sees it, so Ctrl+wheel would stop zooming altogether.
      } else if (ie.type === 'keyDown' && (_ctrl || _meta)) {
        if (ie.key === '+' || ie.key === '=' || ie.key === 'Add') { _ev.preventDefault(); cw.setZoomFactor(Math.min(3, cw.getZoomFactor() * 1.1)); }
        else if (ie.key === '-' || ie.key === 'Subtract') { _ev.preventDefault(); cw.setZoomFactor(Math.max(0.25, cw.getZoomFactor() / 1.1)); }
        else if (ie.key === '0') { _ev.preventDefault(); cw.setZoomFactor(1); }
      }
    } catch (_) {}
  });
  cw.on('did-navigate', (_e, u) => { tab.url = u || tab.url; if (tab.id === S.activeTabId) S.url = tab.url; recordHistory(tab.url, tab.title); pushUpdate(); });
  cw.on('did-navigate-in-page', () => { tab.url = cw.getURL(); if (tab.id === S.activeTabId) S.url = tab.url; pushUpdate(); });
  cw.on('did-start-loading', () => pushUpdate());
  cw.on('did-stop-loading', () => { recordHistory(tab.url, tab.title); pushUpdate(); });
  cw.on('page-title-updated', (_e, t) => { tab.title = t || tab.title; pushUpdate(); });
  cw.on('did-finish-load', () => applyViewOpacity(view, transparencyOp()));
  S.tabs.push(tab);
  applyViewOpacity(view, transparencyOp());
  try {
    cw.on('before-input-event', (_e, input) => {
      if (input.type === 'keyDown' && (input.control || input.meta) && String(input.key).toLowerCase() === 'k') {
        _e.preventDefault();
        setPaletteOpen(!S.paletteOpen);
      }
    });
  } catch (_) {}
  try { cw.loadURL(tab.url).catch(() => {}); } catch (_) {}
  if (switchTo) switchTab(tab.id);
  else pushUpdate();
  return tab;
}

function switchTab(id) {
  const tab = S.tabs.find((t) => t.id === id);
  if (!tab) return;
  const prev = getActiveTab();
  if (prev && prev.id !== id && S.shown && S.parent && !S.parent.isDestroyed()) {
    try { detachView(S.parent, prev.view); } catch (_) {}
  }
  S.activeTabId = id;
  S.url = tab.url;
  if (S.shown && S.parent && !S.parent.isDestroyed()) {
    attachView(S.parent, tab.view);
    layout();
    try { tab.view.webContents.focus(); } catch (_) {}
    // keep the toolbar above the (new) content view in z-order
    if (S.toolbar) { detachView(S.parent, S.toolbar); attachView(S.parent, S.toolbar); }
  }
  pushUpdate();
}

function closeTab(id) {
  const idx = S.tabs.findIndex((t) => t.id === id);
  if (idx < 0) return;
  const tab = S.tabs[idx];
  const wasActive = id === S.activeTabId;
  if (S.shown && S.parent && !S.parent.isDestroyed()) {
    try { detachView(S.parent, tab.view); } catch (_) {}
  }
  try { tab.view.webContents.destroy(); } catch (_) {}
  S.tabs.splice(idx, 1);
  if (!S.tabs.length) {
    S.activeTabId = null;
    S.url = '';
    if (S.shown) hide();
    else pushUpdate();
    return;
  }
  if (wasActive) {
    const next = S.tabs[Math.min(idx, S.tabs.length - 1)];
    switchTab(next.id);
  } else {
    pushUpdate();
  }
}

function loadContent(u) {
  const tab = getActiveTab();
  if (!tab) return;
  const target = normalize(u);
  tab.url = target;
  S.url = target;
  try { tab.view.webContents.loadURL(target).catch(() => {}); } catch (_) {}
}

function destroyAllTabs() {
  for (const t of S.tabs) {
    try { if (S.shown && S.parent && !S.parent.isDestroyed()) detachView(S.parent, t.view); } catch (_) {}
    try { t.view.webContents.destroy(); } catch (_) {}
  }
  S.tabs = [];
  S.activeTabId = null;
  S.url = '';
}

function switchProfile(id) {
  const st = getStore();
  if (!st || !st.setActiveProfile) return;
  const next = st.setActiveProfile(id);
  if (!next) return;
  const keepShown = S.shown;
  destroyAllTabs();
  if (keepShown) {
    createTab(activeHome(), true);
    layout();
  }
  pushUpdate();
  log('profile', next);
  sendStatus('profile: ' + (activeProfile().name || next), 'ok');
}

function currentUrl() {
  const cw = activeWC();
  try { return (cw && cw.getURL()) || (getActiveTab() && getActiveTab().url) || ''; } catch (_) { return ''; }
}

function openInSystemBrowser(url) {
  const u = url || currentUrl();
  if (!u) return false;
  try { shell.openExternal(u); return true; } catch (_) { return false; }
}

function copyUrl(url) {
  const u = url || currentUrl();
  if (!u) return false;
  try { clipboard.writeText(u); return true; } catch (_) { return false; }
}

const PASTE_JS = `(function(url){
  try{
    var tx=document.querySelector('[role="textbox"][data-qa="texty_input"]');
    if(!tx)return 'missing';
    tx.focus();
    var ok=false;
    try{ok=document.execCommand('insertText',false,url);}catch(e){}
    if(!ok){
      try{
        tx.innerText=(tx.innerText||'')+url;
        tx.dispatchEvent(new InputEvent('input',{bubbles:true,data:url,inputType:'insertText'}));
      }catch(e){}
    }
    return 'ok';
  }catch(e){return 'err'}
})`;

async function pasteUrlToSlack(url) {
  const u = url || currentUrl();
  if (!u) return 'empty';
  try { clipboard.writeText(u); } catch (_) {}
  try {
    if (!S.parent || S.parent.isDestroyed()) return 'copied';
    const r = await S.parent.webContents.executeJavaScript('(' + PASTE_JS + ')(' + JSON.stringify(u) + ')', true);
    return r || 'copied';
  } catch (_) { return 'copied'; }
}

function setPaletteOpen(open) {
  S.paletteOpen = !!open;
  toolbarH = S.paletteOpen ? Math.max(toolbarH, 420) : TOOLBAR_H;
  if (S.shown) try { layout(); } catch (_) {}
  try {
    const tw = S.toolbar && S.toolbar.webContents;
    if (tw && !tw.isDestroyed()) tw.send('sb-palette', { open: S.paletteOpen });
  } catch (_) {}
}

function paletteItems(q) {
  const st = getStore();
  const pid = activeProfileId();
  const url = currentUrl();
  const actions = [
    { kind: 'action', id: 'open-system', title: 'Open in system browser', url: url },
    { kind: 'action', id: 'copy-url', title: 'Copy URL', url: url },
    { kind: 'action', id: 'slack-msg', title: 'Add to Slack message', url: url },
    { kind: 'action', id: 'new-tab', title: 'New tab', url: '' },
  ];
  try {
    const profiles = (st && st.listProfiles) ? st.listProfiles() : [];
    profiles.forEach((p) => {
      actions.push({ kind: 'action', id: 'profile:' + p.id, title: 'Switch profile: ' + p.name, url: '' });
    });
  } catch (_) {}
  const tabs = S.tabs.map((t) => ({ kind: 'tab', id: t.id, title: t.title || t.url, url: t.url }));
  const bms = (st && st.listBookmarks) ? st.listBookmarks(pid).map((b) => ({ kind: 'bookmark', id: 'bm:' + b.url, title: b.title, url: b.url })) : [];
  const hist = (st && st.listHistory) ? st.listHistory(pid).map((h) => ({ kind: 'history', id: 'h:' + h.url, title: h.title, url: h.url })) : [];
  const all = actions.concat(tabs).concat(bms).concat(hist);
  const s = getSearch();
  return s ? s.filterItems(all, q).slice(0, 30) : all.slice(0, 30);
}

function runPaletteItem(item) {
  if (!item) return;
  if (item.kind === 'action') {
    if (item.id === 'open-system') { openInSystemBrowser(item.url); sendStatus('opened in system browser', 'ok'); }
    else if (item.id === 'copy-url') { copyUrl(item.url); sendStatus('copied URL', 'ok'); }
    else if (item.id === 'slack-msg') {
      pasteUrlToSlack(item.url).then((r) => {
        sendStatus(r === 'ok' ? 'pasted into Slack' : (r === 'missing' ? 'copied (composer missing)' : 'copied URL'), r === 'ok' ? 'ok' : 'busy');
      }).catch(() => sendStatus('copied URL', 'ok'));
    }
    else if (item.id === 'new-tab') createTab(activeHome(), true);
    else if (item.id.indexOf('profile:') === 0) switchProfile(item.id.slice(8));
  } else if (item.kind === 'tab') {
    switchTab(item.id);
  } else if (item.url) {
    loadContent(item.url);
  }
  setPaletteOpen(false);
}

function layout() {
  if (!S.shown || !S.parent || S.parent.isDestroyed()) return;
  let b;
  try { b = S.parent.getContentBounds(); } catch (_) { return; }
  const w = b.width, hgt = b.height;
  const browserW = Math.max(240, Math.floor(w * (1 - LEFT_RATIO)));
  const x = Math.max(0, w - browserW);
  setBounds(S.toolbar, { x: x, y: SLACK_TOP_H, width: browserW, height: toolbarH });
  const active = getActiveTab();
  if (active) setBounds(active.view, { x: x, y: SLACK_TOP_H + TOOLBAR_H, width: browserW, height: Math.max(50, hgt - SLACK_TOP_H - TOOLBAR_H) });
}

function focusToolbar() {
  setTimeout(() => {
    try {
      const tw = S.toolbar && S.toolbar.webContents;
      if (tw && !tw.isDestroyed()) {
        tw.focus();
        tw.executeJavaScript("document.getElementById('sb-url') && document.getElementById('sb-url').focus()").catch(() => {});
      }
    } catch (_) {}
  }, 120);
}

function show() {
  if (!S.parent || S.parent.isDestroyed()) return;
  if (!S.toolbar) {
    // Own partition: the toolbar runs with nodeIntegration, so it must not share
    // storage or cookies with the untrusted pages loaded in the content tabs.
    const part = session.fromPartition('persist:slack-sb-toolbar');
    S.toolbar = createView({
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      preload: path.join(MOD_DIR, 'sb_toolbar_preload.cjs'),
      session: part,
    });
    S.toolbar.webContents.loadFile(path.join(MOD_DIR, 'sb_toolbar.html')).catch(() => {});
    S.toolbar.webContents.on('did-finish-load', () => applyViewOpacity(S.toolbar, transparencyOp()));
    try {
      S.toolbar.webContents.on('before-input-event', (_e, input) => {
        if (input.type === 'keyDown' && (input.control || input.meta) && String(input.key).toLowerCase() === 'k') {
          _e.preventDefault();
          setPaletteOpen(!S.paletteOpen);
        } else if (input.type === 'keyDown' && input.key === 'Escape' && S.paletteOpen) {
          _e.preventDefault();
          setPaletteOpen(false);
        }
      });
    } catch (_) {}
  }
  if (!S.tabs.length) {
    createTab(activeHome(), false);
  }
  if (!S.activeTabId) S.activeTabId = S.tabs[0].id;
  const active = getActiveTab();
  if (active) attachView(S.parent, active.view);
  attachView(S.parent, S.toolbar);
  S.shown = true;
  layout();
  const cw = active && active.view && active.view.webContents;
  if (cw && !cw.getURL()) { try { cw.loadURL(active.url || activeHome()); } catch (_) {} }
  pushUpdate();
  focusToolbar();
  log('browser shown');
}
try { globalThis.sbShow = show; globalThis.sbHide = hide; globalThis.sbCreateTab = createTab; globalThis.sbSwitchTab = switchTab; globalThis.sbCloseTab = closeTab; } catch (_) {}

function hide() {
  if (!S.parent || S.parent.isDestroyed()) { S.shown = false; return; }
  detachView(S.parent, S.toolbar);
  const active = getActiveTab();
  if (active) detachView(S.parent, active.view);
  S.shown = false;
  try { S.parent.webContents.focus(); } catch (_) {}
  log('browser hidden');
}

function toggle() {
  if (S.shown) hide(); else show();
}

// expose for debugging via --inspect
try { globalThis.sbToggle = toggle; globalThis.sbState = S; } catch (_) {}

// ===================== OWN-DM GATE =====================
// Browser only toggles when the active conversation is the logged-in
// user's own DM ("message yourself").
const PROBE_JS = `(function(){
  var r={href:location.href||'',t:document.title||''};
  try{var t=typeof TS;r.TS=t;if(t!=='undefined'&&TS.boot_data){var b=TS.boot_data;r.uid=b.user_id||'';r.me=(b.self&&(b.self.id))||''}}catch(e){}
  try{var h=document.querySelector('[data-qa="channel_name"]');r.chan=h?h.innerText:''}catch(e){}
  try{var h2=document.querySelector('[data-qa="channel_header"]');r.hdr=h2?(h2.innerText||'').split('\\n').slice(0,3).join('|'):''}catch(e){}
  try{r.bodyAttr={};['data-user-id','data-team-id'].forEach(function(a){if(document.body.getAttribute(a))r.bodyAttr[a]=document.body.getAttribute(a)})}catch(e){}
  try{var map={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i)||'';var m=/^persist-v1::(T[A-Z0-9]+)::(U[A-Z0-9]+)::/.exec(k);if(m){map[m[1]]=m[2]}}r.persistSelf=map}catch(e){}
  try{var yc=document.querySelector('[data-qa="channel-sidebar-channel"][class*="--im-you"][class*="--selected"]');r.youSel=yc?(yc.closest('[data-qa="virtual-list-item"]')||{}).id||'':''}catch(e){}
  try{var cm=/(?:^|\\/)client\\/(T[A-Z0-9]+)(?:\\/([A-Z0-9]+))?/.exec(location.href||'');r.team=cm?cm[1]:'';r.conv=cm&&cm[2]?cm[2]:''}catch(e){}
  try{var tx=document.querySelector('[role="textbox"][data-qa="texty_input"]');r.composer=tx?(tx.innerText||''):''}catch(e){}
  try{var sel='';var items=document.querySelectorAll('[data-qa="virtual-list-item"]');
    for(var i=0;i<items.length;i++){var it=items[i];var row=it.querySelector('[data-qa="channel-sidebar-channel"]');
      if(!row)continue;var cn=String(row.className||'');
      if(!/--selected|--active/.test(cn))continue;
      sel=it.id||'';r.selClass=cn.slice(0,200);r.selName=(row.innerText||'').trim().slice(0,60);break;}
    r.selChan=sel;}catch(e){}
  return JSON.stringify(r);
})()`;

function probe() {
  try {
    if (!S.parent || S.parent.isDestroyed()) return Promise.resolve('');
    return S.parent.webContents.executeJavaScript(PROBE_JS, true);
  } catch (_) {
    return Promise.resolve('');
  }
}
try { globalThis.sbProbe = probe; } catch (_) {}

const OWN = {
  resolved: false,
  map: {},      // teamId -> userId
  selfChan: {}, // teamId -> own-DM channel id (learned from the --im-you row)
  last: null,   // last probe verdict, for logging
  logged: '',   // last logged verdict, so the ticker does not spam sb.log
};

async function resolveSelf() {
  try {
    const raw = await probe();
    const j = JSON.parse(raw || '{}');
    const url = (j.href || '');
    const tm = /\/client\/(T[A-Z0-9]+)/.exec(url);
    const curTeam = tm ? tm[1] : '';
    // source 1: new UI persist-* localStorage keys: persist-v1::<team>::<user>::
    if (j.persistSelf && Object.keys(j.persistSelf).length) {
      OWN.map = Object.assign({}, OWN.map, j.persistSelf);
    }
    // source 2: old TS.boot_data
    const uidOld = (j.uid || '').trim();
    if (uidOld && curTeam) OWN.map[curTeam] = OWN.map[curTeam] || uidOld;
    // Only log when the answer changes: this runs every 400 ms and used to append a
    // line per tick, which is what made sb.log grow without bound.
    const key = curTeam + '|' + (OWN.map[curTeam] || '');
    if (curTeam && OWN.map[curTeam]) {
      OWN.resolved = true;
      if (OWN.logged !== key) { OWN.logged = key; log('self resolved', curTeam, OWN.map[curTeam]); }
    } else if (Object.keys(OWN.map).length) {
      OWN.resolved = true;
      if (OWN.logged !== key) { OWN.logged = key; log('self resolved (team-unmatched)', JSON.stringify(OWN.map)); }
    } else if (OWN.logged !== 'none') {
      OWN.logged = 'none';
      log('self not resolvable yet', j.href || '(no href)');
    }
    j.curTeam = curTeam;
    return j;
  } catch (err) {
    log('resolveSelf err', String(err));
    return null;
  }
}
try { globalThis.sbResolve = resolveSelf; } catch (_) {}

async function isSelfDMActive() {
  try {
    if (!S.parent || S.parent.isDestroyed()) return false;
    const j = await resolveSelf();
    if (!j) return false;
    const team = j.curTeam || j.team || '';
    const conv = String(j.conv || '').trim();
    // AUTHORITATIVE rule: the conversation in the URL must be the own-DM
    // conversation id we pinned at unlock time (typing the phrase proves we
    // were in the own DM at that moment). CSS-class sniffing false-fires on
    // some Slack builds, so the URL decides whenever it is available.
    const known = team ? String(OWN.selfChan[team] || '') : '';
    if (known && conv) { OWN.last = { ok: conv === known, team, selChan: conv, youSel: j.youSel || '', src: 'url' }; return conv === known; }
    // fallback (URL not parseable): the sidebar row flagged as your own DM
    if (j.youSel && /^[A-Z0-9]+$/.test(j.youSel)) {
      if (team) OWN.selfChan[team] = j.youSel;
      OWN.last = { ok: true, team, selChan: j.selChan || '', youSel: j.youSel, src: 'dom' };
      return true;
    }
    const kn2 = team ? OWN.selfChan[team] : '';
    const ok = !!(kn2 && j.selChan && j.selChan === kn2);
    OWN.last = { ok, team, selChan: j.selChan || '', youSel: j.youSel || '', src: 'dom2' };
    return ok;
  } catch (_) {
    return false;
  }
}

// browser lifecycle: unlocked once via secret phrase, visible ONLY in own DM
// (no keyboard shortcut)
let UNLOCKED = false;
let lastDM = null;        // null until first probe
let minimized = false;    // hidden but state kept; restore needs phrase + PIN
let manualHide = false;   // user hid while browsing another convo
function awayLockMs() { return (Number(S.autolockMin) || 0) * 1000; }   // 0 = off
let awaySince = 0;           // when we went away (0 = present); set by stateTick()
let outStreak = 0;           // consecutive OUT probes while visible (flicker guard)

function fullExit() {
  UNLOCKED = false;
  minimized = false;
  manualHide = false;
  awaySince = 0;
  S.paletteOpen = false;
  toolbarH = TOOLBAR_H;
  destroyAllTabs();
  if (S.shown) { detachView(S.parent, S.toolbar); S.shown = false; }
  log('browser full exit');
}

function stateTick() {
  if (!UNLOCKED || minimized) return;
  if (!S.parent || S.parent.isDestroyed()) return;
  if (S.shown) { try { layout(); } catch (_) {} }
  let slackMin = false;
  try { slackMin = S.parent.isMinimized(); } catch (_) {}
  isSelfDMActive().then((ok) => {
    if (lastDM !== ok) log('own-DM gate', ok ? 'IN' : 'OUT', 'team=' + ((OWN.last && OWN.last.team) || '-'), 'chan=' + ((OWN.last && OWN.last.selChan) || '-'), 'you=' + ((OWN.last && OWN.last.youSel) || '-'), 'src=' + ((OWN.last && OWN.last.src) || '-'));
    const away = !ok || slackMin;
    if (!away) {
      outStreak = 0;
      if (awaySince) { log('back within grace period'); awaySince = 0; }  // cancel the timer
      if (!S.shown && !unlockBusy && !manualHide) { log('own DM -> show'); show(); }
    } else {
      // leaving the own DM: take the browser off the wrong conversation right
      // away (2 consecutive OUT probes ~0.4 s to tolerate one-off probe errors),
      // but only auto-LOCK (phrase + PIN again) after the full grace period
      outStreak++;
      if (S.shown && outStreak >= 2) { log('left own DM -> hiding browser'); hide(); }
      if (!awaySince) {
        awaySince = Date.now();
        const _alm0 = awayLockMs();
        if (_alm0 > 0) log('away: ' + (slackMin ? 'slack minimized' : 'left own DM') + ' -> auto lock in ' + (_alm0 / 1000) + 's');
        else log('away: ' + (slackMin ? 'slack minimized' : 'left own DM') + ' (auto-lock off)');
      } else {
        const _alm = awayLockMs();
        if (_alm > 0 && Date.now() - awaySince >= _alm) {
          // stayed away long enough: lock. Re-entry then needs the secret phrase + PIN,
          // exactly as if the minimize button had been pressed.
          awaySince = 0;
          outStreak = 0;
          minimized = true;
          manualHide = false;
          log('away ' + (_alm / 1000) + 's -> auto locked' + (S.shown ? '' : ' (already hidden)'));
          if (S.shown) hide();
        }
      }
    }
    lastDM = ok;
  }).catch(() => {});
}
try { globalThis.sbStateTick = stateTick; } catch (_) {}

// ===================== PIN LOCK =====================
const crypto = require('crypto');
const PIN_FILE = path.join(MOD_DIR, 'sb_pin.json');
const sha256 = (s) => crypto.createHash('sha256').update(String(s), 'utf8').digest('hex');

function pinRead() {
  try { return JSON.parse(fs.readFileSync(PIN_FILE, 'utf8')); } catch (_) { return null; }
}
function pinWrite(pin) {
  try { fs.writeFileSync(PIN_FILE, JSON.stringify({ hash: sha256(pin), set: new Date().toISOString() })); } catch (_) {}
}

let unlockWin = null;
let unlockBusy = false;
let unlockResolve = null;
let unlockMode = 'verify';
let forceSetPin = false;

// fire the success callback and close the window
function unlockSuccess() {
  const cb = unlockResolve;
  unlockResolve = null;
  UNLOCKED = true;
  minimized = false;
  manualHide = false;
  closeUnlock();
  try { if (cb) cb(true); } catch (_) {}
  log('unlock success');
}

function closeUnlock() {
  try { if (unlockWin && !unlockWin.isDestroyed()) unlockWin.close(); } catch (_) {}
  unlockWin = null;
}

// change the user's PIN: verify the old one first, then set a new one
function changePin() {
  if (unlockBusy) return;
  if (!fs.existsSync(PIN_FILE)) {
    // no pin yet -> just set one
    forceSetPin = true;
    requestUnlock(() => { forceSetPin = false; log('pin set'); }, 'set');
    return;
  }
  requestUnlock((ok) => {
    unlockBusy = false;
    if (!ok) { forceSetPin = false; log('pin change cancelled'); return; }
    forceSetPin = true;
    setTimeout(() => {
      requestUnlock(() => { forceSetPin = false; log('pin changed'); }, 'set');
    }, 250);
  }, 'verify');
}

async function requestUnlock(onOk, modeOverride) {
  if (unlockBusy) return;
  let st = false;
  try { st = await isSelfDMActive(); } catch (_) { st = false; }
  if (!st) { log('unlock aborted: not self DM'); return; }
  unlockBusy = true;
  if (modeOverride) unlockMode = modeOverride;
  else unlockMode = fs.existsSync(PIN_FILE) ? 'verify' : 'set';
  try {
    unlockWin = new BrowserWindow({
      width: 340, height: 220, frame: false, resizable: false,
      alwaysOnTop: true, skipTaskbar: true, show: false,
      parent: (S.parent && !S.parent.isDestroyed()) ? S.parent : undefined,
      backgroundColor: '#1a1d21',
      webPreferences: {
        preload: path.join(MOD_DIR, 'sb_preload.cjs'),
        contextIsolation: true, nodeIntegration: false,
      },
    });
    unlockWin.setMenu(null);
    unlockWin.on('closed', () => {
      unlockBusy = false;
      if (unlockResolve) { const cb = unlockResolve; unlockResolve = null; cb(false); }
    });
    // after a successful PIN submit the loader resolves -> callback
    unlockResolve = (ok) => { try { if (ok && onOk) onOk(); } catch (_) {} };
    unlockWin.loadFile(path.join(MOD_DIR, 'sb_unlock.html'), { query: { mode: unlockMode } });
    unlockWin.webContents.once('did-finish-load', () => {
      try { unlockWin.show(); unlockWin.focus(); } catch (_) {}
    });
    log('unlock window opened mode=' + unlockMode);
  } catch (err) {
    unlockBusy = false;
    log('unlock window error', String(err));
  }
}
try { globalThis.sbRequestUnlock = requestUnlock; } catch (_) {}

// pending phrase-unlock pass (once PIN verified from phrase path)
ipcMain.handle('sb-pin-submit', (_ev, pin) => {
  pin = String(pin || '').trim();
  if (!pin) return { ok: false, msg: 'PIN likhen' };
  if (pin.length < 4) return { ok: false, msg: 'minimum 4 character' };
  const existing = pinRead();
  if (forceSetPin && unlockMode === 'set') {
    pinWrite(pin);
    log('pin changed');
    forceSetPin = false;
    unlockSuccess();
    return { ok: true };
  }
  if (existing && existing.hash && unlockMode === 'set') {
    // a pin already exists; entering it here unlocks
    if (existing.hash === sha256(pin)) { unlockSuccess(); return { ok: true }; }
    return { ok: false, msg: 'bhul PIN' };
  }
  if (existing && existing.hash) {
    if (existing.hash === sha256(pin)) {
      log('pin verified');
      unlockSuccess();
      return { ok: true };
    }
    log('pin wrong');
    return { ok: false, msg: 'bhul PIN' };
  }
  // no pin yet -> first use, set it
  pinWrite(pin);
  log('pin set (first time)');
  unlockSuccess();
  return { ok: true };
});
// ===================== SECRET PHRASE TRIGGER =====================
// Type the phrase in the composer of your OWN DM -> unlock prompt -> browser.
// Renderer keeps a capture-phase keydown listener: pressing Enter with the
// phrase in the composer swallows the send, clears the composer and flags.
// ---- secret phrase (default "enjoy you", changeable from settings) ----
function getPhrase() {
  const st = getStore();
  const v = st ? st.getUI().phrase : null;
  return (typeof v === 'string' && v.trim()) ? v.trim() : DEFAULT_PHRASE;
}
function phraseJS() {
  return `(function(){
  var phrase = ${JSON.stringify(getPhrase())};
  if(!window.__sbPhraseInstalled){
    window.__sbPhraseInstalled=1;window.__sbPhrase=0;
    window.__sbPhraseText=phrase;
    document.addEventListener('keydown',function(ev){
      if(ev.key!=='Enter'||ev.shiftKey)return;
      var tx=document.querySelector('[role="textbox"][data-qa="texty_input"]');
      if(!tx)return;
      var t=(tx.innerText||'').toLowerCase().replace(/[\\u2019']/g,"'");
      var p=(window.__sbPhraseText||'').toLowerCase().replace(/[\\u2019']/g,"'");
      if(!p||t.indexOf(p)<0)return;
      try{ev.preventDefault();ev.stopImmediatePropagation()}catch(e){}
      try{tx.innerHTML='';tx.dispatchEvent(new InputEvent('input',{bubbles:true}))}catch(e){}
      window.__sbPhrase=1;
    },true);
  }
  window.__sbPhraseText=phrase;
  if(window.__sbPhrase){window.__sbPhrase=0;
    var tx=document.querySelector('[role="textbox"][data-qa="texty_input"]');
    if(tx){try{tx.innerHTML='';tx.dispatchEvent(new InputEvent('input',{bubbles:true}))}catch(e){}}
    return '1';
  }
  var tx=document.querySelector('[role="textbox"][data-qa="texty_input"]');
  if(!tx)return '0';
  var t=(tx.innerText||'').toLowerCase().replace(/[\\u2019']/g,"'");
  var p=(window.__sbPhraseText||'').toLowerCase().replace(/[\\u2019']/g,"'");
  if(!p||t.indexOf(p)<0)return '0';
  try{tx.innerHTML='';tx.dispatchEvent(new InputEvent('input',{bubbles:true}))}catch(e){}
  return '1';
})()`;
}

let phraseBusy = false;
async function phraseTick() {
  if (S.shown || phraseBusy || unlockBusy) return;
  if (!S.parent || S.parent.isDestroyed()) return;
  phraseBusy = true;
  try {
    const hit = await S.parent.webContents.executeJavaScript(phraseJS(), true).catch(() => '0');
    if (hit === '1') {
      const okDM = await isSelfDMActive();
      if (!okDM) { log('phrase ignored: not own DM'); return; }
      // we are provably in the own DM right now: pin this exact conversation id
      // so the own-DM gate can use exact URL equality from now on
      try {
        const jp = await resolveSelf();
        if (jp && jp.conv && jp.curTeam) {
          OWN.selfChan[jp.curTeam] = jp.conv;
          OWN.resolved = true;
          log('own DM pinned', jp.curTeam, jp.conv);
        }
      } catch (_) {}
      log('phrase detected');
      requestUnlock(() => { isSelfDMActive().then((ok) => { if (ok) show(); }); });
    }
  } catch (_) {}
  finally { phraseBusy = false; }
}
try { globalThis.sbPhraseTick = phraseTick; } catch (_) {}


// ---- self-update (toolbar "Update" button)
let updater = null;
function getUpdater() {
  if (updater) return updater;
  try { updater = require(path.join(MOD_DIR, 'sb_update.cjs')); } catch (err) { log('updater unavailable', String(err && err.message)); }
  return updater;
}

function sendStatus(text, kind) {
  const tw = S.toolbar && S.toolbar.webContents;
  if (!tw || tw.isDestroyed()) return;
  try { tw.send('sb-update-status', { text: text, kind: kind }); } catch (_) {}
}

// ---- bind IPC once
function bindIPC() {
  if (S.ipcBound) return;
  S.ipcBound = true;
  ipcMain.on('sb-go', (_ev, u) => { loadContent(u); });
  ipcMain.on('sb-back', () => {
    const cw = activeWC();
    if (!cw) return;
    if (cw.navigationHistory && cw.navigationHistory.canGoBack()) cw.navigationHistory.goBack();
    else if (cw.canGoBack && cw.canGoBack()) cw.goBack();
  });
  ipcMain.on('sb-fwd', () => {
    const cw = activeWC();
    if (!cw) return;
    if (cw.navigationHistory && cw.navigationHistory.canGoForward()) cw.navigationHistory.goForward();
    else if (cw.canGoForward && cw.canGoForward()) cw.goForward();
  });
  ipcMain.on('sb-reload', () => {
    const cw = activeWC();
    if (cw) cw.reload();
  });
  ipcMain.on('sb-stop', () => {
    const cw = activeWC();
    if (cw) cw.stop();
  });
  ipcMain.on('sb-home', () => { loadContent(activeHome()); });
  ipcMain.on('sb-hide', () => { log('sb-hide received'); toolbarH = TOOLBAR_H; fullExit(); });
  ipcMain.on('sb-min', () => { log('sb-min received'); toolbarH = TOOLBAR_H; minimized = true; manualHide = false; hide(); });
  ipcMain.on('sb-newtab', (_ev, u) => { if (UNLOCKED) createTab(u || activeHome(), true); });
  ipcMain.on('sb-switchtab', (_ev, id) => { if (UNLOCKED) switchTab(id); });
  ipcMain.on('sb-closetab', (_ev, id) => { if (UNLOCKED) closeTab(id); });
  ipcMain.on('sb-devtools', () => {
    const cw = activeWC();
    if (cw) cw.openDevTools({ mode: 'detach' });
  });
  ipcMain.on('sb-preload-ready', () => { log('PRELOAD READY'); });
  ipcMain.on('sb-update-check', () => {
    const u = getUpdater();
    if (!u) { sendStatus('updater missing', 'err'); return; }
    u.checkAndApply(MOD_DIR, (st) => sendStatus(st.text, st.kind))
      .then((r) => {
        log('update check', r.state, (r.changed && r.changed.join(',')) || '', r.error || '');
        if (r && r.state === 'installer') {
          sendStatus('installer launched - Slack will restart', 'ok');
        } else if (r && r.state === 'updated') {
          if (r.needRestart) {
            sendStatus('updated - restart Slack to apply', 'ok');
          } else {
            // toolbar.html only -> hot-reload the toolbar view in place
            try {
              const tw = S.toolbar && S.toolbar.webContents;
              if (tw && !tw.isDestroyed()) { tw.reload(); sendStatus('updated (no restart needed)', 'ok'); }
              else sendStatus('updated - reopen browser', 'ok');
            } catch (_) { sendStatus('updated - reopen browser', 'ok'); }
          }
        } else if (r && r.state === 'current') {
          sendStatus('up to date', 'ok');
        } else if (r && r.state === 'error') {
          sendStatus('update failed: ' + (r.error || '').slice(0, 60), 'err');
        }
      })
      .catch((err) => { log('update check error', String(err && err.message)); sendStatus('update failed', 'err'); });
  });
  // ---- transparency (percentage bar in the toolbar)
  ipcMain.handle('sb-opacity-get', () => { const v = Number(S.opacity); return isFinite(v) ? v : 100; });
  ipcMain.on('sb-opacity', (_ev, pct) => {
    let v = Number(pct);
    if (!isFinite(v)) return;
    v = Math.max(20, Math.min(100, Math.round(v)));
    if (v === S.opacity) return;
    S.opacity = v;
    applyTransparency();
    const st = getStore();
    if (st) st.setUI({ transparency: v });
    log('transparency', v);
  });
  // ---- toolbar menu open/close (grows toolbar to fit the dropdown, overlays content)
  ipcMain.on('sb-menu', (_ev, open) => {
    const want = open ? 400 : TOOLBAR_H;
    if (toolbarH === want) { log('menu', open ? 'open (already sized)' : 'close (already sized)'); return; }
    toolbarH = want;
    if (S.shown && S.parent && !S.parent.isDestroyed()) {
      try { layout(); log('menu', open ? 'open resized->' + toolbarH : 'close resized->' + toolbarH); }
      catch (e) { log('menu layout err', String(e && e.message)); }
    } else {
      log('menu', open ? 'open (not shown)' : 'close (not shown)');
    }
  });
  ipcMain.on('sb-autolock', (_ev, sec) => {
    let v = Number(sec);
    if (!isFinite(v)) return;
    v = Math.max(0, Math.min(3600, Math.round(v)));
    if (v === S.autolockMin) return;
    S.autolockMin = v;
    const st = getStore();
    if (st) st.setUI({ autolockMin: v });
    log('auto-lock', v);
  });
  ipcMain.handle('sb-autolock-get', () => { const v = Number(S.autolockMin); return isFinite(v) ? v : 30; });
  // ---- change PIN (from settings panel)
  ipcMain.on('sb-change-pin', () => { try { changePin(); } catch (e) { log('changePin err', String(e && e.message)); } });
  // ---- change secret phrase (from settings panel) ----
  ipcMain.handle('sb-phrase-get', () => getPhrase());
  ipcMain.handle('sb-phrase-set', (_ev, phrase) => {
    phrase = String(phrase || '').trim();
    if (phrase.length < 3) return { ok: false, msg: 'minimum 3 characters' };
    const st = getStore();
    if (st) st.setUI({ phrase: phrase });
    log('phrase changed to: ' + phrase);
    return { ok: true };
  });
  ipcMain.on('sb-change-phrase', () => {
    try {
      if (unlockBusy) return;
      isSelfDMActive().then((ok) => {
        if (!ok) { log('phrase change aborted: not own DM'); return; }
        const w = new BrowserWindow({
          width: 360, height: 200, frame: false, resizable: false,
          alwaysOnTop: true, skipTaskbar: true, show: false,
          parent: (S.parent && !S.parent.isDestroyed()) ? S.parent : undefined,
          backgroundColor: '#1a1d21',
          webPreferences: { preload: path.join(MOD_DIR, 'sb_preload.cjs'), contextIsolation: true, nodeIntegration: false },
        });
        w.setMenu(null);
        w.loadFile(path.join(MOD_DIR, 'sb_phrase.html'));
        w.webContents.once('did-finish-load', () => { try { w.show(); w.focus(); } catch (_) {} });
        w.on('closed', () => {});
      }).catch(() => {});
    } catch (e) { log('changePhrase err', String(e && e.message)); }
  });
  // ---- settings popup window (floats above everything; auto-closes on blur)
  ipcMain.on('sb-open-settings', () => { openSettingsWindow(); });
  ipcMain.on('sb-open-bookmarks', () => {
    if (S.toolbar && !S.toolbar.isDestroyed()) {
      try { S.toolbar.webContents.executeJavaScript('window.sbToggleBM && window.sbToggleBM()').catch(() => {}); } catch (_) {}
    }
  });
  // ---- bookmarks
  ipcMain.handle('sb-bm-list', () => { const st = getStore(); return st ? st.listBookmarks(activeProfileId()) : []; });
  ipcMain.handle('sb-bm-add', (_ev, p) => {
    const st = getStore();
    if (!st) return [];
    st.addBookmark(p && p.url, p && p.title, activeProfileId());
    log('bookmark added', (p && p.url) || '(none)');
    return st.listBookmarks(activeProfileId());
  });
  ipcMain.handle('sb-bm-del', (_ev, p) => {
    const st = getStore();
    if (!st) return [];
    const next = st.removeBookmark(p && p.url, activeProfileId());
    log('bookmark removed', (p && p.url) || '(none)');
    return next;
  });
  ipcMain.handle('sb-profiles', () => {
    const st = getStore();
    return {
      list: st && st.listProfiles ? st.listProfiles() : [],
      active: activeProfileId(),
    };
  });
  ipcMain.on('sb-profile-switch', (_ev, id) => { if (UNLOCKED) switchProfile(String(id || '')); });
  ipcMain.handle('sb-profile-add', (_ev, p) => {
    const st = getStore();
    if (!st || !st.addProfile) return [];
    st.addProfile(p || {});
    pushUpdate();
    return st.listProfiles();
  });
  ipcMain.handle('sb-profile-del', (_ev, id) => {
    const st = getStore();
    if (!st || !st.removeProfile) return [];
    if (id === activeProfileId()) switchProfile((st.listProfiles().find((x) => x.id !== id) || {}).id);
    st.removeProfile(id);
    pushUpdate();
    return st.listProfiles();
  });
  ipcMain.handle('sb-profile-home', (_ev, p) => {
    const st = getStore();
    if (!st || !st.setProfileHome) return null;
    const r = st.setProfileHome((p && p.id) || activeProfileId(), p && p.home);
    pushUpdate();
    return r;
  });
  ipcMain.handle('sb-history-list', () => {
    const st = getStore();
    return st && st.listHistory ? st.listHistory(activeProfileId()) : [];
  });
  ipcMain.handle('sb-downloads-list', () => {
    const st = getStore();
    return st && st.listDownloads ? st.listDownloads(activeProfileId()) : [];
  });
  ipcMain.on('sb-download-open', (_ev, rec) => {
    try {
      const p = rec && rec.path;
      if (p) shell.showItemInFolder(p);
    } catch (_) {}
  });
  ipcMain.handle('sb-blocker-get', () => {
    const b = getBlocker();
    return b ? b.isEnabled() : false;
  });
  ipcMain.on('sb-blocker-set', (_ev, on) => {
    const b = getBlocker();
    if (!b) return;
    b.setEnabled(!!on);
    const st = getStore();
    if (st) st.setUI({ blocker: !!on });
    sendStatus(on ? 'ad blocker on' : 'ad blocker off', 'ok');
    pushUpdate();
  });
  ipcMain.handle('sb-palette-query', (_ev, q) => paletteItems(q));
  ipcMain.on('sb-palette-run', (_ev, item) => { if (UNLOCKED) runPaletteItem(item); });
  ipcMain.on('sb-palette-toggle', () => { if (UNLOCKED && S.shown) setPaletteOpen(!S.paletteOpen); });
  ipcMain.on('sb-palette-close', () => setPaletteOpen(false));
  ipcMain.on('sb-open-system', (_ev, u) => { openInSystemBrowser(u); });
  ipcMain.on('sb-copy-url', (_ev, u) => { if (copyUrl(u)) sendStatus('copied URL', 'ok'); });
  ipcMain.on('sb-slack-msg', (_ev, u) => {
    pasteUrlToSlack(u).then((r) => {
      sendStatus(r === 'ok' ? 'pasted into Slack' : (r === 'missing' ? 'copied (composer missing)' : 'copied URL'), r === 'ok' ? 'ok' : 'busy');
    }).catch(() => {});
  });
  ipcMain.on('sb-zoom', (_ev, dir) => {
    const cw = activeWC();
    if (!cw) return;
    try {
      const cur = cw.getZoomFactor();
      const factor = dir === 'in' ? cur * 1.1 : (dir === 'out' ? cur / 1.1 : 1);
      const next = (dir === 'reset') ? 1 : Math.min(3, Math.max(0.25, factor));
      cw.setZoomFactor(next);
      log('ZOOM', dir, '->', next);
    } catch (e) { log('ZOOM err', String(e)); }
  });
}

// ---- parent window discovery
function isSlackMain(win) {
  try {
    const u = (win.webContents && win.webContents.getURL()) || '';
    const b = win.getBounds();
    return /https?:\/\/[^/]*(slack\.(com|gov))/i.test(u) && b.width > 700;
  } catch (_) {
    return false;
  }
}

function bindParent(win) {
  if (S.parent === win) return;
  S.parent = win;
  const relayout = () => { if (S.shown) layout(); };
  ['resize', 'move', 'maximize', 'unmaximize', 'restore', 'show', 'enter-full-screen', 'leave-full-screen'].forEach((ev) => {
    try { win.on(ev, relayout); } catch (_) {}
  });
  try {
    win.on('closed', () => {
      if (S.parent === win) {
        S.parent = null;
        S.shown = false;
      }
    });
  } catch (_) {}
  // state ticker: keep browser synced to the active conversation
  try {
    win.webContents.on('did-navigate', () => stateTick());
  } catch (_) {}
  log('parent bound', win.id);
}

function scan() {
  try {
    for (const w of BrowserWindow.getAllWindows()) {
      if (isSlackMain(w)) { bindParent(w); break; }
    }
  } catch (_) {}
}

function onWindowCreated(win) {
  try {
    if (isSlackMain(win)) { bindParent(win); return; }
    const retry = () => { if (!S.parent || S.parent.isDestroyed()) scan(); };
    retry();
    try { win.webContents.on('did-navigate', retry); win.webContents.on('did-finish-load', retry); } catch (_) {}
    try { win.on('ready-to-show', retry); } catch (_) {}
  } catch (_) {}
}

try {
  app.whenReady().then(() => {
    const st = getStore();
    if (st) {
      try { if (st.listProfiles) st.listProfiles(); } catch (_) {}
      const saved = Number(st.getUI().transparency);
      if (isFinite(saved)) S.opacity = Math.max(20, Math.min(100, saved));
      const al = Number(st.getUI().autolockMin);
      if (isFinite(al) && al >= 0) S.autolockMin = al;
      const blk = st.getUI().blocker;
      const b = getBlocker();
      if (b && typeof blk === 'boolean') b.setEnabled(blk);
    }
    bindIPC();
    scan();
    // secret phrase watcher + renderer Enter-guard install
    setInterval(() => { phraseTick(); stateTick(); }, 400);
    // safety net: keep scanning briefly in case the main window loads late
    let n = 0;
    const iv = setInterval(() => {
      n++;
      if (S.parent && !S.parent.isDestroyed()) { clearInterval(iv); return; }
      scan();
      if (n > 36) clearInterval(iv);
    }, 2500);
  });
  app.on('browser-window-created', (_ev, win) => { try { onWindowCreated(win); } catch (_) {} });
  app.on('will-quit', () => { try { globalShortcut.unregister(ACCEL); } catch (_) {} });
} catch (err) {
  log('boot hook error', err && err.stack);
}

log('sb_main loaded', 'electron', process.versions.electron);
