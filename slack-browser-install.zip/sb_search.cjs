'use strict';

function score(item, q) {
  if (!q) return 0;
  const title = String((item && item.title) || '').toLowerCase();
  const url = String((item && item.url) || '').toLowerCase();
  const query = String(q).toLowerCase().trim();
  if (!query) return 0;
  if (title === query) return 1000;
  if (title.indexOf(query) === 0) return 800;
  if (title.indexOf(query) >= 0) return 500;
  if (url.indexOf(query) >= 0) return 300;
  const parts = query.split(/\s+/).filter(Boolean);
  if (parts.length > 1 && parts.every((p) => title.indexOf(p) >= 0 || url.indexOf(p) >= 0)) return 200;
  return -1;
}

function filterItems(items, q) {
  const list = Array.isArray(items) ? items : [];
  const query = String(q || '').trim();
  if (!query) return list.slice();
  return list
    .map((item) => ({ item: item, s: score(item, query) }))
    .filter((x) => x.s >= 0)
    .sort((a, b) => b.s - a.s)
    .map((x) => x.item);
}

module.exports = { filterItems: filterItems, score: score };
